WSUWP Spine Parent Theme
========================

Provides the [spine and skeleton framework](https://github.com/washingtonstateuniversity/wsu-spine) for the WSU Web in WordPress
