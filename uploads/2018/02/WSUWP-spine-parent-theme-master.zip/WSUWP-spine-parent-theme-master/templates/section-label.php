<?php /* Template Name: Section Label */

wp_safe_redirect( home_url() );
