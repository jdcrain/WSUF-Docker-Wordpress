<?php

get_template_part( 'spine/body' );
