<?php
/**
 * @package Make
 */

/**
 * Execute code after the builder stage is displayed.
 *
 * @since 1.2.3.
 */
do_action( 'make_after_builder_stage' );
?>
</div>
